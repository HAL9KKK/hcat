powershell C:\fix-hosts.ps1
cmd /c ping -t localhost > $null